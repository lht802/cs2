# 排产易APS系统架构

![image-20220601162259141](imgs/1.png)

![image-20220601162335317](imgs/2.png)